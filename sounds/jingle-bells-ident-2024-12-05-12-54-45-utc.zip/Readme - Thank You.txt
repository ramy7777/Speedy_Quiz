Thank you for licensing this item and supporting my sound effects. 

I am happy that my work helps enhance your project. Therefore, please rate the item that you purchased on Envato Elements or AudioJungle. Further, I am always interested to know how you have used my sound effects, so please drop me a line and tell me. It would be greatly appreciated! :)

If you need any further information, feel free to email me at ldjaudio@gmail.com

Best,
LDj_Audio